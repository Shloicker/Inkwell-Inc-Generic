import text_adventure

giant_spider = text_adventure.enemy("Giant Spider", "A big scary spider.", 100, 50, 25, 25)

print(giant_spider.observe_enemy())