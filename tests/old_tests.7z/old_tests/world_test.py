import text_adventure

room = text_adventure.loot_room(0, 0, "A cool room.", [], 0)
print(text_adventure.tile_exists(0, 1))