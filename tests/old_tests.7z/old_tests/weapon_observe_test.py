#checks that we can observe a weapon

import text_adventure

diamond_sword = text_adventure.weapon("Diamond Sword", "A sword made of diamond.", 1000, 100)
output = diamond_sword.observe_item()
test_output = "Diamond Sword\n-----\nA sword made of diamond.\nValue: 1000\nDamage: 100\n"
assert (output) == (test_output)