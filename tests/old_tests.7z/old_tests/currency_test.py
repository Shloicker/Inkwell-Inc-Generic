#checks that we can reference our currency in a string

import text_adventure

print("You have 15 {}.".format(text_adventure.currency))