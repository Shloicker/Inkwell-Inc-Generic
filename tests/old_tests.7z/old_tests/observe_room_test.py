import text_adventure

gold_necklace = text_adventure.item("Gold Necklace", "A necklace made of gold.", 1000)
room = text_adventure.loot_room(0, 0, "A room with loot in it.", [gold_necklace], 100)
player = text_adventure.player([], 0)

print(player.observe("room"))