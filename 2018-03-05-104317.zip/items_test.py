import text_adventure

diamond_sword = text_adventure.item("Diamond Sword", "A sword made of diamond.", 1000)
print(diamond_sword)