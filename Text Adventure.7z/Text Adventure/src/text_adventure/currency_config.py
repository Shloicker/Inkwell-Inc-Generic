# this module determines the name of the in game currency. Change the word in the inverted commas to your desired name of currency.
world_currency = "gold"