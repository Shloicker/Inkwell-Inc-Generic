from text_adventure import enemy

giant_spider = enemy("Giant Spider", "A venemous spider is large as a bear.", 200, 25, 15, 15)
skeleton = enemy("Skeleton", "An undead decayed to bare bones somehow standing wields a rusted blade.", 100, 35, 60, 35)