import game_items

player_inventory = [game_items.iron_sword, game_items.iron_armour, game_items.iron_shield]      #the items that the player will start with
player_currency = 100                                                                           #the amount of currency that the player will start with