import text_adventure

gold_necklace = text_adventure.item("Gold Necklace", "A necklace made of gold.", 1000)
silver_necklace = text_adventure.item("Silver Necklace", "A necklace made of silver.", 500)
shop = text_adventure.shop_room(0, 0, "A cool shop.", [], 1000)
player1 = text_adventure.player([gold_necklace, silver_necklace], 1000)

print("Starting player inventory:\n" + player1.take_inventory())
print("\nStarting shop inventory:\n" + shop.view_shop_inventory())
print(shop.sell_item(player1, silver_necklace))
print("\nEnding shop inventory:\n" + shop.view_shop_inventory())
print("\nEnding player inventory:\n" + player1.take_inventory())