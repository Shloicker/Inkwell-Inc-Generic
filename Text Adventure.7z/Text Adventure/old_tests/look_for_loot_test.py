import text_adventure

gold_necklace = text_adventure.item("Gold Necklace", "A necklace made of gold.", 1000)
silver_necklace = text_adventure.item("Silver Necklace", "A necklace made of silver.", 500)
room = text_adventure.loot_room(0, 0, "A room with loot.", [gold_necklace, silver_necklace], 100)
player1 = text_adventure.player([], 0)

print(player1.do_action(text_adventure.LookAround))