import text_adventure

iron_sword = text_adventure.weapon("Iron Sword", "A sword made of iron.", 500, 50)
iron_shield = text_adventure.shield("Iron Shield", "A shield made of iron.", 500, 25)
player1 = text_adventure.player([iron_sword, iron_shield], 100)

print(player1.do_action(text_adventure.TakeInventory))