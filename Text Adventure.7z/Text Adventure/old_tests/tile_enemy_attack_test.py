import text_adventure

iron_shield = text_adventure.shield("Iron Shield", "A shield made of iron.", 500, 25)
iron_armour = text_adventure.armour("Iron Armour", "Armour made of iron.", 1000, 25)
spider_poison = text_adventure.healing_consumable("Spider Poison", "Poison from a spider.", 50, -25)
player1 = text_adventure.player([iron_shield, iron_armour], 0)
giant_spider = text_adventure.enemy("Giant Spider", "A big horrible spider.", 100, 50, 50, 25)
spider_room = text_adventure.combat_room(0, 0, "This room has a spider in it!", "This room has a dead spider in it. Its poison is harvestable.", [spider_poison], 0, giant_spider)

player1.equip(iron_shield)
player1.equip(iron_armour)

print(spider_room.enemy_attack(player1))