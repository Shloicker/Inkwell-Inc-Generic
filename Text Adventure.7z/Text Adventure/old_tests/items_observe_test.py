#checks that we can observe an item

import text_adventure

diamond_sword = text_adventure.item("Diamond Sword", "A sword made of diamond.", 1000)
output = diamond_sword.observe_item()
test_output = "Diamond Sword\n-----\nA sword made of diamond.\nValue: 1000\n"
assert (output) == (test_output)