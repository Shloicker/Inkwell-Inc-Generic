import text_adventure

iron_sword = text_adventure.weapon("Iron Sword", "A sword made of iron.", 500, 50)
player1 = text_adventure.player([iron_sword], 0)

print(player1.do_action(text_adventure.Equip, iron_sword))