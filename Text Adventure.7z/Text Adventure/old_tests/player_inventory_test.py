#checks that we can use the 'take inventory' function

import text_adventure

iron_sword = text_adventure.item("Iron Sword", "An Iron Sword.", 500)
gold_necklace = text_adventure.item("Gold Necklace", "A necklace of gold.", 5000)

player1 = text_adventure.player([iron_sword, gold_necklace], 0)
output = player1.take_inventory()
test_output = "Iron Sword\nGold Necklace\nYou have 0 currency."
assert (output) == (test_output)