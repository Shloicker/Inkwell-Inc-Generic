#checks all functoinalities for equipping items

import text_adventure

diamond_sword = text_adventure.weapon("Diamond Sword", "A sword made from diamond.", 1000, 100)
iron_sword = text_adventure.weapon("Iron Sword", "A sword made from diamond.", 500, 50)
steel_plate_armour = text_adventure.armour("Steel Plate Armour", "A tough armour made from steel.", 1000, 30)
iron_shield = text_adventure.shield("Iron Shield", "A shield made from iron.", 500, 25)

player1 = text_adventure.player([diamond_sword, iron_sword, steel_plate_armour, iron_shield], 0)

print(player1.equip(diamond_sword))
print(player1.equip(steel_plate_armour))
print(player1.equip(iron_shield))
print(player1.equip(iron_sword) + "\n------\n") #this should unequip diamond sword

print(player1.take_inventory())