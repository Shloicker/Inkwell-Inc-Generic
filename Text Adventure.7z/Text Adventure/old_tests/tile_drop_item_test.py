import text_adventure

iron_sword = text_adventure.weapon("Iron Sword", "A sword made of iron.", 500, 50)
gold_necklace = text_adventure.item("Gold Necklace", "A necklace made of gold.", 1000)
silver_necklace = text_adventure.item("Silver Necklace", "A necklace made of silver.", 750)
player1 = text_adventure.player([iron_sword, gold_necklace], 0)
room = text_adventure.loot_room(0, 0, "You enter a room with a silver necklace on the floor.", [silver_necklace], 0)

print(room.drop_item(player1, iron_sword))
print("Player inventory:")
print(player1.take_inventory())
print("Tile inventory:")
print(room.view_tile_inventory())