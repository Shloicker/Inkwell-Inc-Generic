import text_adventure

room = text_adventure.loot_room(0, 0, "A really cool room.", [], 1000)
player1 = text_adventure.player([], 0)

print("Starting inventories:\n" + room.view_tile_inventory() + "\n" + player1.take_inventory())
print(room.pick_up_item(player1, "gold"))
print("Ending inventories:\n" + room.view_tile_inventory() + "\n" + player1.take_inventory())
print("Trying to drop gold:\n" + room.drop_item(player1, "gold"))