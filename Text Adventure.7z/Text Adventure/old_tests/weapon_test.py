#checks that we can create a weapon, a subclass of items, and return it as a string

import text_adventure

diamond_sword = text_adventure.weapon("Diamond Sword", "A diamond sword.", 1000, 100)
assert (str(diamond_sword)) == ("Diamond Sword")