#checks all functionalities for attacking enemies

import text_adventure

iron_sword = text_adventure.weapon("Iron Sword", "A sword made of iron.", 500, 1000)
iron_shield = text_adventure.shield("Iron Shield", "A shield made of iron.", 500, 25)
iron_armour = text_adventure.armour("Iron Armour", "Armour made of iron.", 100, 50)
player1 = text_adventure.player([iron_sword, iron_shield, iron_armour], 0)
player1.equip(iron_sword)
player1.equip(iron_shield)
player1.equip(iron_armour)

giant_spider = text_adventure.enemy("Giant Spider", "A very large spider.", 100, 50, 50, 25)
spider_room = text_adventure.combat_room(0, 0, "This room has a spider in it!", "This room has a dead spider in it.", [], 0, giant_spider)

print(player1.attack(giant_spider))