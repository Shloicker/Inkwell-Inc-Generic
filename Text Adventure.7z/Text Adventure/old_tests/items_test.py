#checks that we can create a generate item and return it as a string

import text_adventure

diamond_sword = text_adventure.item("Diamond Sword", "A sword made of diamond.", 1000)
assert (str(diamond_sword)) == ("Diamond Sword")