import text_adventure

player1 = text_adventure.player([], 0)
room1 = text_adventure.starting_room("You've started the journey.")
room2 = text_adventure.loot_room(1, 0, "You are now in a new room.", [], 0)

print(player1.move_east())