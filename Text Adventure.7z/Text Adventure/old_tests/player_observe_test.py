#tests the observe function when called by the player

import text_adventure

iron_sword = text_adventure.weapon("Iron Sword", "A sword made of iron.", 500, 50)
iron_shield = text_adventure.shield("Iron Shield", "A shield made of iron.", 350, 25)
iron_armour = text_adventure.armour("Iron Armour", "A set of armour made of iron.", 1000, 35)
giant_spider = text_adventure.enemy("Giant Spider", "A big scary spider.", 100, 50, 25, 25)
player1 = text_adventure.player([iron_sword, iron_shield, iron_armour], 0)

print(player1.do_action(text_adventure.Observe, iron_sword) + "\n" + player1.do_action(text_adventure.Observe, iron_shield) + "\n" + player1.do_action(text_adventure.Observe, iron_armour) + "\n" + player1.do_action(text_adventure.Observe, giant_spider))