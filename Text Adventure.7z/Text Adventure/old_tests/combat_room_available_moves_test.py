import text_adventure

bandit = text_adventure.enemy("Bandit", "A fearsome bandit.", 100, 50, 25, 25)
dead_bandit = text_adventure.enemy("Dead Bandit", "A dead bandit.", -10, 50, 25, 25)
combatroom1 = text_adventure.combat_room(0, 0, "A room with a bandit in it.", "A room with a dead bandit in it.", [], 0, bandit)
combatroom2 = text_adventure.combat_room(0, 1, "null", "A room with a dead bandit in it.", [], 0, dead_bandit)

for action in combatroom1.available_actions():
    print(action)
for action in combatroom2.available_actions():
    print(action)