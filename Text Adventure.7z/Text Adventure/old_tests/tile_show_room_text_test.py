import text_adventure

room = text_adventure.loot_room(0, 0, "A really cool room.", [], 0)

print(room.show_room_text())